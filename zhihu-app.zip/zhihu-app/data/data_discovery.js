/**
 * Created by Rebecca_Han on 16/10/26.
 */
module.exports = {

}

var discovery= {
    "id": 3,
        "data": [
        {
            "question_id": 1,
            "answer_id": 3,
            "feed_source_id": 23,
            "feed_source_name": "Lelouch",
            "feed_source_txt": "     回答了问题",
            "feed_source_img": "../../images/icon1.jpg",
            "question": "有哪些书非常有利于年轻人未来发展？",
            "answer_ctnt": "年轻人，跟你说句真话，没有什么书是必读的。你这么问，国学迷会跟你说四书必读，科学迷会跟你说时间简史必读，文学迷会跟你说百年孤独必读，信教的会跟你说圣经必读...",
            "good_num": "112",
            "comment_num": "18"
        },
        {
            "question_id": 2,
            "answer_id": 25,
            "feed_source_id": 24,
          "feed_source_name": "德克萨斯",
          "feed_source_txt": "     回答了问题",
          "feed_source_img": "../../images/icon2.jpg",
          "question": "学霸学累了会干什么？",
          "answer_ctnt": "学霸？累？\n学霸和累，是2个世界的词好吗？看看剑桥学霸是怎样连续24小时学习的...",
          "good_num": "23",
          "comment_num": "3"
        },
        {
            "question_id": 3,
            "answer_id": 61,
            "feed_source_id": 25,
          "feed_source_name": "SilverBullet",
          "feed_source_txt": "     回答了问题",
          "feed_source_img": "../../images/icon3.jpg",
          "question": "如果人工智能迎来下一个寒冬，你认为会是卡在什么问题上？",
          "answer_ctnt": "我认为人工智能在最近几年突然成井喷式发展最重要的推动力就是Nvidia黄夹克家的CUDA之GPU将算力直接以几何级数的级别提升了，使能够真正在算力的加持下验证>改进>验证实现了螺旋上升...",
          "good_num": "23333",
          "comment_num": "2333"
        },
        {
            "question_id": 4,
            "answer_id": 3,
            "feed_source_id": 23,
          "feed_source_name": "Lelouch",
          "feed_source_txt": "     回答了问题",
          "feed_source_img": "../../images/icon1.jpg",
          "question": "有哪些书非常有利于年轻人未来发展？",
          "answer_ctnt": "年轻人，跟你说句真话，没有什么书是必读的。你这么问，国学迷会跟你说四书必读，科学迷会跟你说时间简史必读，文学迷会跟你说百年孤独必读，信教的会跟你说圣经必读...",
          "good_num": "112",
          "comment_num": "18"
        },
        {
            "question_id": 5,
            "answer_id": 25,
            "feed_source_id": 24,
          "feed_source_name": "德克萨斯",
          "feed_source_txt": "     回答了问题",
          "feed_source_img": "../../images/icon2.jpg",
          "question": "学霸学累了会干什么？",
          "answer_ctnt": "学霸？累？\n学霸和累，是2个世界的词好吗？看看剑桥学霸是怎样连续24小时学习的...",
          "good_num": "23",
          "comment_num": "3"
        },
        {
            "question_id": 6,
            "answer_id": 61,
            "feed_source_id": 25,
          "feed_source_name": "SilverBullet",
          "feed_source_txt": "     回答了问题",
          "feed_source_img": "../../images/icon3.jpg",
          "question": "如果人工智能迎来下一个寒冬，你认为会是卡在什么问题上？",
          "answer_ctnt": "我认为人工智能在最近几年突然成井喷式发展最重要的推动力就是Nvidia黄夹克家的CUDA之GPU将算力直接以几何级数的级别提升了，使能够真正在算力的加持下验证>改进>验证实现了螺旋上升...",
          "good_num": "23333",
          "comment_num": "2333"
        },
        {
            "question_id": 7,
            "answer_id": 3,
            "feed_source_id": 23,
          "feed_source_name": "Lelouch",
          "feed_source_txt": "     回答了问题",
          "feed_source_img": "../../images/icon1.jpg",
          "question": "有哪些书非常有利于年轻人未来发展？",
          "answer_ctnt": "年轻人，跟你说句真话，没有什么书是必读的。你这么问，国学迷会跟你说四书必读，科学迷会跟你说时间简史必读，文学迷会跟你说百年孤独必读，信教的会跟你说圣经必读...",
          "good_num": "112",
          "comment_num": "18"
        },
        {
            "question_id": 8,
            "answer_id": 25,
            "feed_source_id": 24,
          "feed_source_name": "德克萨斯",
          "feed_source_txt": "     回答了问题",
          "feed_source_img": "../../images/icon2.jpg",
          "question": "学霸学累了会干什么？",
          "answer_ctnt": "学霸？累？\n学霸和累，是2个世界的词好吗？看看剑桥学霸是怎样连续24小时学习的...",
          "good_num": "23",
          "comment_num": "3"
        }

    ]

}

module.exports.discovery = discovery;